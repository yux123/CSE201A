﻿
CREATE DATABASE takeout;
GO

USE takeout;



CREATE TABLE foodType(--食品种类

id INT PRIMARY KEY,

typeName VARCHAR(50)--种类名字                

);

INSERT INTO foodType(id,typeName) values(1,'Biergarten Faves'),
(2,'Burgers'),
(3,'Sandwiches'),
(4,'Salads'),
(5,'Schnitzels'),
(6,'RESERVE RUN FARM STEAKS'),
(7,'ENTRÉES'),
(8,'Kinder Menu')



CREATE TABLE food(

 id INT identity(1,1)  PRIMARY KEY  ,

foodName VARCHAR(50),--视频名字                

foodType_id INT,--种类            

price FLOAT,--价钱                    


description VARCHAR(500),--描述                  

 img VARCHAR(1000) --图                  

);

INSERT INTO food(id,foodName,foodType_id,price,description,img) values
(1,'Sauerkraut Balls',1,7,'tasty','https://www.google.com/url?sa=i&source=images&cd=&ved=2ahUKEwjosZe1wNrjAhVCU80KHQpZD2kQjRx6BAgBEAU&url=https%3A%2F%2Fwww.thefooddictator.com%2Fhirshon-akron-deep-fried-sauerkraut-balls%2F&psig=AOvVaw3FnnINtrQTmoo2praDqi1Y&ust=1564502482441083'),
(2,'Chessburger',2,8,'tasty','https://www.google.com/url?sa=i&source=images&cd=&ved=2ahUKEwie243PwNrjAhX0Ap0JHZ8CBe0QjRx6BAgBEAU&url=https%3A%2F%2Fwww.foodrepublic.com%2Frecipes%2Fall-american-cheeseburger-recipe%2F&psig=AOvVaw2-UKRvC2yiLrUvDS8NfcMN&ust=1564502631250706'),
(3,'Pork Belly Reuben',3,8,'tasty','https://www.google.com/url?sa=i&source=images&cd=&ved=2ahUKEwjn__LvwNrjAhVDCM0KHe6VAN0QjRx6BAgBEAU&url=https%3A%2F%2Fwww.thrillist.com%2Ffood%2Fseattle%2Fwa%2F98103%2Ffremont%2Fhungers-pork-belly-reuben_bacon_bizarre-food_cooking_sandwiches&psig=AOvVaw1VNUyjreiylheiCdIzigmP&ust=1564502699600575'),
(4,'Caesar',4,6,'tasty','https://www.google.com/url?sa=i&source=images&cd=&ved=2ahUKEwjXnoCKwdrjAhUMX80KHY9tC7cQjRx6BAgBEAU&url=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FCaesar_salad&psig=AOvVaw3Nf5o2xk0W155fgHtk-pLa&ust=1564502755571240'),
(5,'Wiener',5,10,'tasty','https://www.google.com/imgres?imgurl=https%3A%2F%2Fwww.meatsandsausages.com%2Fpublic%2Fimages%2Fsausage-recipes%2Fwiener.jpg&imgrefurl=https%3A%2F%2Fwww.meatsandsausages.com%2Fsausage-recipes%2Fwiener&docid=sQq0bSLfjyupkM&tbnid=4-sA7o_OQnkvsM%3A&vet=10ahUKEwidoa-kwdrjAhVPCM0KHXf1CwgQMwg_KAAwAA..i&w=876&h=657&bih=888&biw=1920&q=Wiener&ved=0ahUKEwidoa-kwdrjAhVPCM0KHXf1CwgQMwg_KAAwAA&iact=mrc&uact=8'),
(6,'Aged 8 OZ Filet Mignon',6,34,'tasty','https://www.google.com/aclk?sa=l&ai=DChcSEwjd77O6wdrjAhUS28AKHVabCQ0YABABGgJpbQ&sig=AOD64_1Mx3LSPEm_ocD9NFNSBAuAGR-fkQ&ctype=5&q=&ved=0ahUKEwjZy626wdrjAhVMUs0KHcKlAuIQvhcIQg&adurl='),
(7,'The Chop',7,22,'good','https://www.google.com/url?sa=i&source=images&cd=&ved=2ahUKEwj315rTwdrjAhWbZs0KHSPOANUQjRx6BAgBEAU&url=https%3A%2F%2Fwww.misstamchiak.com%2Fthe-chop-house-katong%2F&psig=AOvVaw38QEstBJg9hXEtVh-I7JR3&ust=1564502895027280'),
(8,'Chicken Tenders and Fries',8,10,'good','https://www.google.com/imgres?imgurl=https%3A%2F%2Fd9hyo6bif16lx.cloudfront.net%2Flive%2Fimg%2Fproduction%2Fdetail%2Fmenu%2Flunch-dinner_999-combohs_country-chicken-tenders-fries.jpg&imgrefurl=https%3A%2F%2Fwww.friendlysrestaurants.com%2Fmenu-item%2Fcountry-chicken-tenders-fries%2F&docid=ElbJMX-nvtwbHM&tbnid=avkq-Lhcjat09M%3A&vet=10ahUKEwiPgcfnwdrjAhXQVs0KHSLdCxoQMwhCKAAwAA..i&w=1280&h=720&bih=888&biw=1920&q=Chicken%20Tenders%20and%20Fries&ved=0ahUKEwiPgcfnwdrjAhXQVs0KHSLdCxoQMwhCKAAwAA&iact=mrc&uact=8')



CREATE TABLE orders(

 id INT identity(111,1)  PRIMARY KEY  ,


orderDate DATETIME,--订单日期                     

totalPrice FLOAT,--订单价格                 

orderStatus INT DEFAULT 0--订单状态        

);



CREATE TABLE orderDetail(

 id INT PRIMARY KEY identity(1,1)  , 

orderId INT,--订单编号                                

food_id INT,--食品编号                              

foodCount INT

);

CREATE TABLE client(
   id INT PRIMARY KEY,
   clientId int,--这个当用户名
   password VARCHAR(60)--密码
   );

CREATE TABLE clientinformation(
   id INT PRIMARY KEY,
   clientId int,--这个当用户名
   password VARCHAR(60),--密码
   Fname VARCHAR(60),--名
   Lname VARCHAR(60),--姓
   gender VARCHAR(60),--性别
   address VARCHAR(200),--地址
   city  VARCHAR(200),--城市
   mobile VARCHAR(200),--手机
   Email VARCHAR(200),--邮箱
   );
CREATE TABLE administor(--admin
   id INT PRIMARY KEY,
   adId int,--这个当admin的用户名
   password VARCHAR(60)--密码
   );

   CREATE TABLE payment(
 id INT PRIMARY KEY,
 email VARCHAR(200),
 type  VARCHAR(200),--卡的种类
 bankName VARCHAR(200), --银行名字
 cardNo  VARCHAR(200),--卡号
 ccv  INT,--安全码
 amount  FLOAT--价格
 )
 GO


ALTER TABLE food ADD CONSTRAINT fk_food_foodType_id FOREIGN KEY(foodType_id) REFERENCES foodType(id);


ALTER TABLE orderDetail ADD CONSTRAINT orderDetail_order_id FOREIGN KEY(orderId) REFERENCES orders(id);



ALTER TABLE orderDetail ADD CONSTRAINT orderDetail_food_id FOREIGN KEY(food_id)REFERENCES food(id);

create view DDVIEW as
select o1.id,f1.img,f1.foodName,f1.price,o1.orderDate,o1.totalPrice
from orders o1 left join orderDetail o2 on (o1.id=o2.orderId) left join food f1 on (o2.food_id=f1.id) where o1.orderStatus=0;

drop view DDVIEW

update orders  set  orderStatus=1 where 